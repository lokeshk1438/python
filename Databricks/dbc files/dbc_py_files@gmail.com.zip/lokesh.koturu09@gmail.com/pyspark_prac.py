# Databricks notebook source
from pyspark.sql import SparkSession

# COMMAND ----------

spark = SparkSession.builder.appName("Analysis").getOrCreate()

sc = spark.sparkContext

# COMMAND ----------

# MAGIC 
# MAGIC %fs
# MAGIC 
# MAGIC ls /FileStore/tables/

# COMMAND ----------

# creating an RDD from a list

sc.parallelize(['hello', 'world']).collect()

# COMMAND ----------

rdd1 = sc.parallelize([
	('Sepal.Length', [5.1,4.9,4.7,4.6]),
	('Sepal.Width', [3.5,3.0,3.2,3.1]),
	('Species', ['setosa','setosa','setosa','setosa']) 
])

# COMMAND ----------

print("No of Partitions", rdd1.getNumPartitions())
print("Storage Level", rdd1.getStorageLevel())

# COMMAND ----------

rdd2 = sc.parallelize([
    ('area', ['tpt', 'ctr']),
    ('country', ['ind'])
])

# COMMAND ----------

rdd2.collect()

# COMMAND ----------

# convert the RDD to python dictionary object

dict1 = rdd2.collectAsMap()

# COMMAND ----------

(dict1)

# COMMAND ----------

def rdd_split(x):
    return x.split(",")

sc.textFile(iris_path).map(lambda x: rdd_split(x)).take(2)

# COMMAND ----------

# if-else in list comprehension
# https://stackoverflow.com/questions/4260280/if-else-in-a-list-comprehension

lst = ['5.1', '3.5', '1.4', '0.2', 'setosa']

# COMMAND ----------

res = [float(x) if not x.isalpha() else x for x in lst]

# COMMAND ----------

# Sorting RDD

res1 = [x for x in res if not str(x).isalpha()]

# COMMAND ----------

res1.sort(key=int)

# COMMAND ----------

res1

# COMMAND ----------

sorted(res1, key=lambda x:x-2)

# COMMAND ----------

lst1 = ['233', '21', 'LongSleeve Logo Jersey  L', '29.0807', 'Multi', '48.0673', '28.8404']

# COMMAND ----------

[x for x in lst1 if not x.isalpha()]

# COMMAND ----------

for x in lst1:
#     print(x)
#     print("-----")
    if x.isdigit() or x.isdecimal():
        print(x)
#     print("-----")

# COMMAND ----------

lst2 = ['233',
  '21',
  'LongSleeve Logo Jersey  L',
  '29.0807',
  'Multi',
  '48.0673',
  '28.8404']

# COMMAND ----------

res = [x for x in lst2]

# COMMAND ----------

[x for x in res if (x.strip()).isalpha()]

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### intersection

# COMMAND ----------

lst1 = sc.parallelize(['a', 'b', 'c'])
lst2 = sc.parallelize(['d', 'e', 'f', 'a'])

# COMMAND ----------

lst1.intersection(lst2).collect()

# COMMAND ----------

# MAGIC %md ### join

# COMMAND ----------

loc1 = sc.parallelize([('emp1', [1, 2, 3, 4, 5]), ('emp2', [3, 6, 7, 2, 7])])
loc2 = sc.parallelize([('emp2', [5, 3, 9, 1, 4]), ('emp1', [7, 0, 1, 5, 6])])

# COMMAND ----------

final_join = loc1.join(loc2) # by default join is performed on keys of the RDD

# COMMAND ----------

final_join.collect()

# COMMAND ----------

final_join.map(lambda x: [x[0], x[1][1] ]).collect()

# COMMAND ----------

