# Databricks notebook source
from pyspark.sql import SparkSession

# COMMAND ----------

spark = SparkSession.builder.appName("Analysis").getOrCreate()

sc = spark.sparkContext

# COMMAND ----------

# MAGIC %md
# MAGIC ### 1. Importing the Data

# COMMAND ----------

DimeEmployee_RDD = sc.textFile(r"/FileStore/tables/DimEmployee.csv")
DimProduct_RDD = sc.textFile(r"/FileStore/tables/DimProduct.csv")
FactResellerSales_RDD = sc.textFile(r"/FileStore/tables/FactResellerSales.csv")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 2.1 Split the RDD's based on delimiter

# COMMAND ----------


DimeEmployee_RDD = DimeEmployee_RDD.map(lambda x: x.split(","))
DimProduct_RDD = DimProduct_RDD.map(lambda x: x.split(","))
FactResellerSales_RDD = FactResellerSales_RDD.map(lambda x: x.split(","))


# replace nulls or NA's with 0
blanks = ['', 'NA']

DimeEmployee_RDD = DimeEmployee_RDD.map(lambda x: [u'0' if i in blanks else i for i in x])
DimProduct_RDD = DimProduct_RDD.map(lambda x: [u'0' if i in blanks else i for i in x])
FactResellerSales_RDD = FactResellerSales_RDD.map(lambda x: [u'0' if i in blanks else i for i in x])

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### 3. Creating Key-Value Pairs in RDD

# COMMAND ----------

DimeEmployee_RDD_split = DimeEmployee_RDD.map(lambda x: (float(x[0]), [float(x[1]), float(x[2]), x[3]] ) )
DimProduct_RDD_split = DimProduct_RDD.map(lambda x: (float(x[0]), [ float(x[1]), x[2], float(x[3]), x[4], float(x[5]), float(x[6]) ]) )
FactResellerSales_RDD_split = FactResellerSales_RDD.map(lambda x: (float(x[0]), [float(i) for i in x[1:] ] ) )

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### 4 sorting the RDD --> sortBy

# COMMAND ----------

DimeEmployee_RDD_split_sort = DimeEmployee_RDD_split.sortByKey(ascending=True, keyfunc=lambda x: x)
DimProduct_RDD_split_sort = DimProduct_RDD_split.sortByKey(ascending=True, keyfunc=lambda x: x)
FactResellerSales_RDD_split_sort = FactResellerSales_RDD_split.sortByKey(ascending=True, keyfunc=lambda x: x)

# COMMAND ----------

DimeEmployee_RDD_temp = DimeEmployee_RDD.map(lambda x: [x[0], [i for i in x[1:]]] )

# COMMAND ----------

def func(lst):
    temp1 = [str(i) for i in lst[:8]]
    temp2 = [float(j) for j in lst[8:]]
    temp1.extend(temp2)
    return temp1

# COMMAND ----------

FactResellerSales_RDD_temp = FactResellerSales_RDD.map(lambda x: [ x[5], func(x) ] )

# COMMAND ----------

rf = FactResellerSales_RDD_temp.join(DimeEmployee_RDD_temp)

# COMMAND ----------

rf.take(1)

# COMMAND ----------

rf.map(lambda x: (x[0], x[1][0] )).take(1)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 5 - Join the RDD's

# COMMAND ----------

reseller_prod = DimProduct_RDD_split_sort.join(FactResellerSales_RDD_split_sort)

# COMMAND ----------

reseller_prod.take(1)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Loop Through Values - foreach

# COMMAND ----------

# creating a RDD using textFile function
iris_path = r"/FileStore/tables/iris_site.csv"
iris_RDD = sc.textFile(iris_path)
iris_RDD_split = iris_RDD.map(lambda x: x.split(","))

# COMMAND ----------

iris_RDD_split.take(1)

# COMMAND ----------

iris_RDD_split_mod = iris_RDD_split.map(lambda x: ( ('sepal.length', float(x[0])), ('sepal.width', float(x[1])), ('petal.length', float(x[2])), ('petal.widht', float(x[3])) ))

# COMMAND ----------

def f(x): print(x)

# COMMAND ----------

a= spark.createDataFrame(["SAM","JOHN","AND","ROBIN","ANAND"], "string").toDF("Name")

# COMMAND ----------

a.show()

# COMMAND ----------

a.foreach(f)

# COMMAND ----------

