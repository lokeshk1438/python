# Databricks notebook source
from pyspark.sql import SparkSession

# COMMAND ----------

spark = SparkSession.builder.appName("Analysis").getOrCreate()

sc = spark.sparkContext

# COMMAND ----------

# MAGIC 
# MAGIC %fs
# MAGIC 
# MAGIC ls /FileStore/tables/

# COMMAND ----------

# creating a RDD using textFile function

iris_path = r"/FileStore/tables/iris_site.csv"

iris_RDD = sc.textFile(iris_path)

# COMMAND ----------

iris_RDD

# COMMAND ----------

iris_RDD.collect()

# COMMAND ----------

# MAGIC %md
# MAGIC ### 1. Importing the Data

# COMMAND ----------

DimeEmployee_RDD = sc.textFile(r"FileStore/tables/DimEmployee.csv")
DimProduct_RDD = sc.textFile(r"/FileStore/tables/DimProduct.csv")
FactResellerSales_RDD = sc.textFile(r"/FileStore/tables/FactResellerSales.csv")

# COMMAND ----------

print(DimeEmployee_RDD.take(1))
print(DimProduct_RDD.take(1))
print(FactResellerSales_RDD.take(1))

# COMMAND ----------

# returning name of the RDD

DimeEmployee_RDD.name()

# COMMAND ----------

# setting name of the RDD

DimeEmployee_RDD.setName("EmployeeName")

# COMMAND ----------

DimeEmployee_RDD.name()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### 2. split based on delimiter

# COMMAND ----------

iris_RDD_split = iris_RDD.map(lambda x: x.split(","))

# COMMAND ----------

iris_RDD_split.take(5)

# COMMAND ----------

# multiple operations in single line

# iris_path --> /FileStore/tables/iris_site.csv

sc.textFile(iris_path).map(lambda x: x.split(",")).take(2)

# COMMAND ----------

def rdd_split(x):
    return x.split(",")

sc.textFile(iris_path).map(lambda x: rdd_split(x)).take(2)

# COMMAND ----------

# 2. Split the RDD's
DimeEmployee_RDD = DimeEmployee_RDD.map(lambda x: x.split(","))
DimProduct_RDD = DimProduct_RDD.map(lambda x: x.split(","))
FactResellerSales_RDD = FactResellerSales_RDD.map(lambda x: x.split(","))


# COMMAND ----------

iris_RDD_split.map(lambda x: x).take(5)

# COMMAND ----------

# type casting single column

iris_RDD_split.map(lambda x: float(x[0])).take(10)

# COMMAND ----------

# type casting all values from 2nd column and python Loop with RDD
for i in iris_RDD_split.map(lambda x: float(x[1])).collect():
    print(type(i))

# COMMAND ----------

# Type Casting All Columns Values

iris_RDD_split.map(lambda x: x).take(5)

# COMMAND ----------

# iris_RDD_split.map(lambda x: [float(x[0]), float(x[1]), float(x[2]), float(x[3]), x[4]]).collect()

iris_RDD_split_casted = iris_RDD_split.map(lambda y: [float(x) if not x.isalpha() else x for x in y] )

# COMMAND ----------

iris_RDD_split_casted.take(5)

# COMMAND ----------

# Map --> creates collections of collection items
# iris_RDD_split.map(lambda x: (("sepal.length",float(x[0])), ("sepal.width",float(x[1])), ("petal.length",float(x[2])), ("petal.width",float(x[3]))) ).take(1)

# to reduce it to single collection use flatMap
iris_RDD_split.flatMap(lambda x: (("sepal.length",float(x[0])), ("sepal.width",float(x[1])), ("petal.length",float(x[2])), ("petal.width",float(x[3]))) ).take(2)


# COMMAND ----------

# 3. Creating Key-Value Pairs in RDD

# DimeEmployee_RDD_split = DimeEmployee_RDD.map(lambda x: (float(x[0]), [float(x[1]), float(x[2]), x[3]]))

DimeEmployee_RDD_split = DimeEmployee_RDD.map(lambda x: (float(x[0]), [float(i) if not i.isalpha() else i for i in x[1:] ] ) )
DimProduct_RDD_split = DimProduct_RDD.map(lambda x: (float(x[0]), [float(x[1]), float(x[2]), x[3]]))
FactResellerSales_RDD_split = FactResellerSales_RDD.map(lambda x: (float(x[0]), [float(x[1]), float(x[2]), x[3]]))


# COMMAND ----------

DimProduct_RDD.take(2)

# COMMAND ----------

DimProduct_RDD.map(lambda x: (float(x[0]), [ i if not i.isalpha() else i for i in x[1:] ] ) ).take(1)

# DimProduct_RDD.map(lambda x: (float(x[0]), [float(i) if not i.isalpha() for i in x[1:]] ) )

# COMMAND ----------



# COMMAND ----------

print(DimProduct_RDD.take(3))


# COMMAND ----------

# DimProduct_RDD.map(lambda x: (x[0], [float(i) for i in x[1:] if not i.isalpha()] )).take(3)

# COMMAND ----------



# COMMAND ----------

iris_mod = iris_RDD_split.map(lambda y: [float(x) if not x.isalpha() else x for x in y])

# COMMAND ----------

# 4.1 sorting the RDD --> example

iris_mod.sortBy(lambda x: x[0]).take(10)

# COMMAND ----------

iris_mod_2 = iris_RDD_split.map(lambda x: (x[4], x[:4]))

# COMMAND ----------

iris_mod_2.sortByKey(ascending=True, keyfunc=lambda x: x).take(10)

# COMMAND ----------

print(DimeEmployee_RDD.take(1))
print(DimProduct_RDD.take(1))
print(FactResellerSales_RDD.take(1))

# COMMAND ----------

DimeEmployee_RDD.take(1)

# COMMAND ----------

# DimeEmployee_RDD.map(lambda x: (x[3], [i for i in x if not i.isalpha()]))

DimeEmployee_RDD_sort = DimeEmployee_RDD.map(lambda x: (x[0], [x[1:]]))

# COMMAND ----------

DimeEmployee_RDD_sort.sortByKey(ascending=True, keyfunc=lambda x: x).take(10)

# COMMAND ----------

# DimProduct_RDD_split.take(1)

# COMMAND ----------



# COMMAND ----------

# practice

DimeEmployee_RDD = sc.textFile(r"FileStore/tables/DimEmployee.csv").map(lambda x: x.split(","))

# COMMAND ----------

DimeEmployee_RDD.take(1)

# COMMAND ----------

blanks = ['', 'NA']

# COMMAND ----------

DimeEmployee_RDD = DimeEmployee_RDD.map(lambda x: [u'0' if i in blanks else i for i in x])

# COMMAND ----------

DimeEmployee_RDD_split = DimeEmployee_RDD.map(lambda x: (float(x[0]), [float(x[1]), float(x[2]), x[3]] ))

# COMMAND ----------

DimeEmployee_RDD_split.sortByKey(ascending=True, keyfunc=lambda x: x).take(210)

# COMMAND ----------

