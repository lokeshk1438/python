# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

arrayData = [
        ('James',['Java','Scala'],{'hair':'black','eye':'brown'}),
        ('Michael',['Spark','Java',None],{'hair':'brown','eye':None}),
        ('Robert',['CSharp',''],{'hair':'red','eye':''}),
        ('Washington',None,None),
        ('Jefferson',['1','2'],{})] 

# COMMAND ----------

df = spark.createDataFrame(data=arrayData, schema=['Name', 'KnownLanguages', 'Properties'])

# COMMAND ----------

df.printSchema()

# COMMAND ----------

df.show(10,0)

# COMMAND ----------

df_pand = df.select('knownlanguages').toPandas()

# COMMAND ----------

df_pand.loc[0][0]

# COMMAND ----------

# explode funtion

df.select('name', 'properties',  explode(df['knownLanguages'])).show(10, 0)

# COMMAND ----------

df.select('name', 'properties',  explode(df['properties'])).show(10, 0)

# COMMAND ----------

# explode outer 

df.select('name',  explode_outer(df['knownLanguages'])).show(10, 0)

# COMMAND ----------

df.select('name',  explode_outer(df['properties'])).show(10, 0)

# COMMAND ----------

# posexplode

df.select('name',  posexplode(df['knownLanguages'])).show(10, 0)

# COMMAND ----------

df.select('name',  posexplode_outer(df['properties'])).show(10, 0)

# COMMAND ----------

