# Databricks notebook source
from pyspark.sql import SparkSession

# COMMAND ----------

spark = SparkSession.builder.appName("Analysis").getOrCreate()

sc = spark.sparkContext

# COMMAND ----------

# MAGIC 
# MAGIC %fs
# MAGIC 
# MAGIC ls /FileStore/tables/

# COMMAND ----------

# creating a RDD using textFile function
iris_path = r"/FileStore/tables/iris_site.csv"
iris_RDD = sc.textFile(iris_path)

# COMMAND ----------

iris_RDD

# COMMAND ----------

iris_RDD.take(3)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 1. Importing the Data

# COMMAND ----------

DimeEmployee_RDD = sc.textFile(r"/FileStore/tables/DimEmployee.csv")
DimProduct_RDD = sc.textFile(r"/FileStore/tables/DimProduct.csv")
FactResellerSales_RDD = sc.textFile(r"/FileStore/tables/FactResellerSales.csv")

# COMMAND ----------

print(DimeEmployee_RDD.take(1))
print(DimProduct_RDD.take(1))
print(FactResellerSales_RDD.take(1))

# COMMAND ----------

# returning name of the RDD

DimeEmployee_RDD.name()

# COMMAND ----------

# setting name of the RDD

DimeEmployee_RDD.setName("EmployeeName")

# COMMAND ----------

DimeEmployee_RDD.name()

# COMMAND ----------

# store the RDD on a file or on server

iris_RDD.saveAsTextFile(r"/FileStore/tables/iris_RDD_test.csv")

# COMMAND ----------

# total partitions RDD used is 2 thus it saves the data in 2 different files

iris_RDD.getNumPartitions()

# COMMAND ----------

# MAGIC %fs
# MAGIC 
# MAGIC ls /FileStore/tables/iris_RDD_test.csv

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### 2. split based on delimiter

# COMMAND ----------

iris_RDD_split = iris_RDD.map(lambda x: x.split(","))

# COMMAND ----------

iris_RDD_split.take(5)

# COMMAND ----------

# multiple operations in single line

# iris_path --> /FileStore/tables/iris_site.csv

sc.textFile(iris_path).map(lambda x: x.split(",")).take(2)

# COMMAND ----------

def rdd_split(x):
    return x.split(",")

sc.textFile(iris_path).map(lambda x: rdd_split(x)).take(2)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 2.1 Split the RDD's based on delimiter

# COMMAND ----------


DimeEmployee_RDD = DimeEmployee_RDD.map(lambda x: x.split(","))
DimProduct_RDD = DimProduct_RDD.map(lambda x: x.split(","))
FactResellerSales_RDD = FactResellerSales_RDD.map(lambda x: x.split(","))


# replace nulls or NA's with 0
blanks = ['', 'NA']

DimeEmployee_RDD = DimeEmployee_RDD.map(lambda x: [u'0' if i in blanks else i for i in x])
DimProduct_RDD = DimProduct_RDD.map(lambda x: [u'0' if i in blanks else i for i in x])
FactResellerSales_RDD = FactResellerSales_RDD.map(lambda x: [u'0' if i in blanks else i for i in x])

# COMMAND ----------

# type casting single column

iris_RDD_split.map(lambda x: float(x[0])).take(10)

# COMMAND ----------

# type casting all values from 2nd column and python Loop with RDD
for i in iris_RDD_split.map(lambda x: float(x[1])).collect():
    print(type(i))

# COMMAND ----------

# type-casting all the columns

# iris_RDD_split.map(lambda x: [float(x[0]), float(x[1]), float(x[2]), float(x[3]), x[4]]).collect()

iris_RDD_split_casted = iris_RDD_split.map(lambda y: [float(x) if not x.isalpha() else x for x in y] )

# COMMAND ----------

iris_RDD_split_casted.take(5)

# COMMAND ----------

# Map --> creates collections of collection items
# iris_RDD_split.map(lambda x: (("sepal.length",float(x[0])), ("sepal.width",float(x[1])), ("petal.length",float(x[2])), ("petal.width",float(x[3]))) ).take(1)

# to reduce it to single collection use flatMap
iris_RDD_split.flatMap(lambda x: (("sepal.length",float(x[0])), ("sepal.width",float(x[1])), ("petal.length",float(x[2])), ("petal.width",float(x[3]))) ).take(2)


# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### 3. Creating Key-Value Pairs in RDD

# COMMAND ----------

DimeEmployee_RDD.take(1)

# COMMAND ----------

DimeEmployee_RDD_split = DimeEmployee_RDD.map(lambda x: (float(x[0]), [float(x[1]), float(x[2]), x[3]] ) )
DimProduct_RDD_split = DimProduct_RDD.map(lambda x: (float(x[0]), [ float(x[1]), x[2], float(x[3]), x[4], float(x[5]), float(x[6]) ]) )
FactResellerSales_RDD_split = FactResellerSales_RDD.map(lambda x: (float(x[0]), [float(i) for i in x[1:] ] ) )


# COMMAND ----------

iris_mod = iris_RDD_split.map(lambda y: [float(x) if not x.isalpha() else x for x in y])

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### 4 sorting the RDD --> sortBy

# COMMAND ----------

iris_mod_sort = iris_mod.sortBy(lambda x: x[0])

# COMMAND ----------

# iris_mod_2 = iris_RDD_split.map(lambda x: (x[4], x[:4]))

iris_mod_2 = iris_mod_sort.map(lambda x: (x[0], x[1:]))

# COMMAND ----------

iris_mod_2.take(1)

# COMMAND ----------

iris_mod_2.sortByKey(ascending=True, keyfunc=lambda x: x).take(10)

# COMMAND ----------

print(DimeEmployee_RDD_split.take(1))
print(DimProduct_RDD_split.take(1))
print(FactResellerSales_RDD_split.take(1))

# COMMAND ----------

DimeEmployee_RDD_split_sort = DimeEmployee_RDD_split.sortByKey(ascending=True, keyfunc=lambda x: x)
DimProduct_RDD_split_sort = DimProduct_RDD_split.sortByKey(ascending=True, keyfunc=lambda x: x)
FactResellerSales_RDD_split_sort = FactResellerSales_RDD_split.sortByKey(ascending=True, keyfunc=lambda x: x)

# COMMAND ----------

DimProduct_RDD_split_sort.take(2)

# COMMAND ----------

for i in DimeEmployee_RDD_split.take(2):
    print(i)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Union of Multiple RDD's

# COMMAND ----------

# iris_path --> '/FileStore/tables/iris_site.csv'

iris_RDD_split.take(2)

# COMMAND ----------

sl = iris_RDD_split.map(lambda x: ['sepal.length', float(x[0])])
sw = iris_RDD_split.map(lambda x: ['sepal.width', float(x[1])])
pl = iris_RDD_split.map(lambda x: ['petal.length', float(x[2])])
pw = iris_RDD_split.map(lambda x: ['petal.width', float(x[3])])
cv = iris_RDD_split.map(lambda x: ['species', x[4]])

# COMMAND ----------

print(sl.take(2))
print(sw.take(2))
print(pl.take(2))
print(pw.take(2))
print(cv.take(2))


# COMMAND ----------

union_data = sc.union([sl, sw, pl, pw, cv])

# COMMAND ----------

union_data.take(2)

# COMMAND ----------

print(FactResellerSales_RDD.take(1))
print(DimeEmployee_RDD.take(1))

# COMMAND ----------

DimeEmployee_RDD_temp = DimeEmployee_RDD.map(lambda x: [x[0], [i for i in x[1:]]] )

# COMMAND ----------

def func(lst):
    temp1 = [str(i) for i in lst[:8]]
    temp2 = [float(j) for j in lst[8:]]
    temp1.extend(temp2)
    return temp1

# COMMAND ----------

FactResellerSales_RDD_temp = FactResellerSales_RDD.map(lambda x: [ x[5], func(x) ] )

# COMMAND ----------

rf = FactResellerSales_RDD_temp.join(DimeEmployee_RDD_temp)

# COMMAND ----------

rf.take(1)

# COMMAND ----------

rf.map(lambda x: (x[0], x[1][0] )).take(1)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 5 - Join the RDD's

# COMMAND ----------

reseller_prod = DimProduct_RDD_split_sort.join(FactResellerSales_RDD_split_sort)

# COMMAND ----------

reseller_prod.take(1)

# COMMAND ----------

