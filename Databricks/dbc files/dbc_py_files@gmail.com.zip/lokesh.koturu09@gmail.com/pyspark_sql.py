# Databricks notebook source
st = "Lokesh Koturu"

# COMMAND ----------

st = st.replace(" ", "")

# COMMAND ----------

" ".join(st)

# COMMAND ----------

name = "impetus"

# COMMAND ----------

name_list = list(iter(name))

# COMMAND ----------

name_list

# COMMAND ----------

for i in name_list:
    print(" "*name_list.index(i), i)

for i in name_list:

    print(name_list.index(i)*" ", i)