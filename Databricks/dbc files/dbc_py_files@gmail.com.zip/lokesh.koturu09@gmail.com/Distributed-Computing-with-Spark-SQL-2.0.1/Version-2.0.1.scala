// Databricks notebook source
// MAGIC 
// MAGIC %md # Course: Distributed-Computing-with-Spark-SQL
// MAGIC * Version 2.0.1
// MAGIC * Built 2021-10-15 01:25:05 UTC
// MAGIC * Git revision: 465c96c478597f63694b6987cb3fb9aeb380d891
// MAGIC 
// MAGIC Copyright © 2021 Databricks, Inc.