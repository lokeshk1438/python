# Databricks notebook source
# MAGIC %fs ls /FileStore/tables

# COMMAND ----------

dimemp = r"/FileStore/tables/DimEmployee.csv"
dimprod = r"/FileStore/tables/DimProduct.csv"
factseller = r"/FileStore/tables/FactResellerSales.csv"

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *

# COMMAND ----------

spark = SparkSession.builder.appName("Mini Project").getOrCreate()

# COMMAND ----------

sc = spark.sparkContext

# COMMAND ----------

DimeEmployee_RDD = sc.textFile(dimemp)
DimProduct_RDD = sc.textFile(dimprod)
FactResellerSales_RDD = sc.textFile(factseller)

# COMMAND ----------

FactResellerSales_RDD.getNumPartitions()

# COMMAND ----------

DimeEmployee_RDD.take(1)

# COMMAND ----------

# dummy exercise

df = spark.createDataFrame(sc.parallelize([['1', 'val1, val2, val3, val4'], ['2', 'val1, val2, val3, val4'], ['3', 'val1, val2, val3, val4'], ['4', 'val1, val2, val3, val4']]), ["col1", "col2"])


# COMMAND ----------

df.show(5,0)

# COMMAND ----------

df = df.select("col1", split("col2", ", ").alias("col2"))

# COMMAND ----------

nbcolumns = [x for x in df.collect()[0][1]]

# COMMAND ----------

nbcolumns

# COMMAND ----------

df = df.select("col1", *[df['col2'][i].alias("col2{0}".format(i)) for i in range(len(nbcolumns))])

# COMMAND ----------

df.show(5,0)

# COMMAND ----------

sc.parallelize(((1,11),(1),(11),(11,1))).countByValue().items()

# COMMAND ----------

sc.parallelize((('1',11),('1'),('11'),('11',1))).countByKey().items()

# COMMAND ----------

sc.parallelize([['a',1],['b',2],['a',3],['a',4]]).foldByKey(0, add).collect()

# COMMAND ----------

