# Databricks notebook source
import pandas as pd
import random
import numpy as np

from pyspark.sql import SparkSession

# COMMAND ----------

spark = SparkSession.builder.appName("Working with Spark").getOrCreate()

# COMMAND ----------

# MAGIC %md
# MAGIC # 1. Simple Functions

# COMMAND ----------

# MAGIC %md
# MAGIC ## Read Data

# COMMAND ----------

cases = spark.read.load("/FileStore/tables/Case.csv",format="csv", sep=",", inferSchema="true", header="true")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Show Data

# COMMAND ----------

cases.show()

# COMMAND ----------

cases.limit(10).toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Change Column Names

# COMMAND ----------

cases = cases.withColumnRenamed("infection_case","infection_source")

# COMMAND ----------

cases = cases.toDF(*['case_id', 'province', 'city', 'group', 'infection_case', 'confirmed',
       'latitude', 'longitude'])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Select Columns

# COMMAND ----------

cases = cases.select('province','city','infection_case','confirmed')

# COMMAND ----------

cases.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Sort

# COMMAND ----------

cases.sort("confirmed").show()

# COMMAND ----------

# descending Sort
from pyspark.sql import functions as F
cases.sort(F.desc("confirmed")).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Cast

# COMMAND ----------

from pyspark.sql.types import IntegerType, StringType, DoubleType

# COMMAND ----------

cases = cases.withColumn('confirmed', F.col('confirmed').cast(IntegerType()))
cases = cases.withColumn('city', F.col('city').cast(StringType()))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Filter

# COMMAND ----------

cases.filter((cases.confirmed>10) & (cases.province=='Daegu')).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## GroupBy

# COMMAND ----------

from pyspark.sql import functions as F

cases.groupBy(["province","city"]).agg(F.sum("confirmed") ,F.max("confirmed")).show()

# COMMAND ----------

cases.groupBy(["province","city"]).agg(F.sum("confirmed").alias("TotalConfirmed"),F.max("confirmed").alias("MaxFromOneConfirmedCase")).show()

# COMMAND ----------

cases.groupBy(["province","city"]).agg(
    F.sum("confirmed").alias("TotalConfirmed"),\
    F.max("confirmed").alias("MaxFromOneConfirmedCase")\
    ).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Joins

# COMMAND ----------

regions = spark.read.load("/home/rahul/projects/sparkdf/coronavirusdataset/Region.csv",format="csv", sep=",", inferSchema="true", header="true")
regions.limit(10).toPandas()

# COMMAND ----------

cases = cases.join(regions, ['province','city'],how='left')

# COMMAND ----------

cases.limit(10).toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC # 2. Broadcast/Map Side Joins

# COMMAND ----------

big = pd.DataFrame({'A':[1,1,1,1,2,2,2,2],'price': [i for i in range(8)]}) 

small = pd.DataFrame({'A':[1,1,1,1,2,2],'agg':['sum','mean','max','min','sum','mean']}) 

# COMMAND ----------

big

# COMMAND ----------

small

# COMMAND ----------

big.merge(small,on = ['A'],how='left')

# COMMAND ----------

# MAGIC %md
# MAGIC Such sort of operations is aplenty in Spark where you might want to apply multiple operations to a particular key. But assuming that the key data in the Big table is large, it will involve a lot of data movement. And sometimes so much that the application itself breaks. A small optimization then you can do when joining on such big tables(assuming the other table is small) is to broadcast the small table to each machine when you perform a join. You can do this easily using the broadcast keyword.

# COMMAND ----------

from pyspark.sql.functions import broadcast
cases = cases.join(broadcast(regions), ['province','city'],how='left')

# COMMAND ----------

cases

# COMMAND ----------

# MAGIC %md
# MAGIC # 3. Using SQL with Spark

# COMMAND ----------

# Reading Original Cases Back again
cases = spark.read.load("/home/rahul/projects/sparkdf/coronavirusdataset/Case.csv",format="csv", sep=",", inferSchema="true", header="true")

# COMMAND ----------

cases.registerTempTable('cases_table')
newDF = sqlContext.sql('select * from cases_table where confirmed>100')

# COMMAND ----------

newDF.show()

# COMMAND ----------

# MAGIC %md
# MAGIC # 4. Create New Columns

# COMMAND ----------

# MAGIC %md
# MAGIC ## Using Spark Native Functions

# COMMAND ----------

casesWithNewConfirmed = cases.withColumn("NewConfirmed", 100 + F.col("confirmed"))
casesWithNewConfirmed.show()

# COMMAND ----------

casesWithExpConfirmed = cases.withColumn("ExpConfirmed", F.exp("confirmed"))
casesWithExpConfirmed.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Spark UDFs

# COMMAND ----------

import pyspark.sql.functions as F
from pyspark.sql.types import *
def casesHighLow(confirmed):
    if confirmed < 50: 
        return 'low'
    else:
        return 'high'
    
#convert to a UDF Function by passing in the function and return type of function
casesHighLowUDF = F.udf(casesHighLow, StringType())

CasesWithHighLow = cases.withColumn("HighLow", casesHighLowUDF("confirmed"))
CasesWithHighLow.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Using RDDs

# COMMAND ----------

import math
from pyspark.sql import Row
def rowwise_function(row):
    # convert row to python dictionary:
    row_dict = row.asDict()
    # Add a new key in the dictionary with the new column name and value.
    # This might be a big complex function.
    row_dict['expConfirmed'] = float(np.exp(row_dict['confirmed']))
    # convert dict to row back again:
    newrow = Row(**row_dict)
    # return new row
    return newrow

# convert cases dataframe to RDD
cases_rdd = cases.rdd

# apply our function to RDD
cases_rdd_new = cases_rdd.map(lambda row: rowwise_function(row))

# Convert RDD Back to DataFrame
casesNewDf = sqlContext.createDataFrame(cases_rdd_new)

casesNewDf.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pandas UDF

# COMMAND ----------

cases.printSchema()

# COMMAND ----------

from pyspark.sql.types import IntegerType, StringType, DoubleType, BooleanType
from pyspark.sql.types import StructType, StructField

# Declare the schema for the output of our function

outSchema = StructType([StructField('case_id',IntegerType(),True),
                        StructField('province',StringType(),True),
                        StructField('city',StringType(),True),
                        StructField('group',BooleanType(),True),
                        StructField('infection_case',StringType(),True),
                        StructField('confirmed',IntegerType(),True),
                        StructField('latitude',StringType(),True),
                        StructField('longitude',StringType(),True),
                        StructField('normalized_confirmed',DoubleType(),True)
                       ])
# decorate our function with pandas_udf decorator
@F.pandas_udf(outSchema, F.PandasUDFType.GROUPED_MAP)
def subtract_mean(pdf):
    # pdf is a pandas.DataFrame
    v = pdf.confirmed
    v = v - v.mean()
    pdf['normalized_confirmed'] = v
    return pdf

confirmed_groupwise_normalization = cases.groupby("infection_case").apply(subtract_mean)

confirmed_groupwise_normalization.limit(10).toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC # 5. Spark Window Functions

# COMMAND ----------

timeprovince = spark.read.load("/home/rahul/projects/sparkdf/coronavirusdataset/TimeProvince.csv",format="csv", \
                        sep=",", inferSchema="true", header="true")
timeprovince.show()


# COMMAND ----------

# MAGIC %md
# MAGIC # Ranking

# COMMAND ----------

from pyspark.sql.window import Window
windowSpec = Window().partitionBy(['province']).orderBy(F.desc('confirmed'))
cases.withColumn("rank",F.rank().over(windowSpec)).show()

# COMMAND ----------

# MAGIC %md
# MAGIC # Lag 

# COMMAND ----------

from pyspark.sql.window import Window
windowSpec = Window().partitionBy(['province']).orderBy('date')
timeprovinceWithLag = timeprovince.withColumn("lag_7",F.lag("confirmed", 7).over(windowSpec))

timeprovinceWithLag.filter(timeprovinceWithLag.date>'2020-03-10').show()

# COMMAND ----------

# MAGIC %md
# MAGIC # Rolling Aggregations

# COMMAND ----------

from pyspark.sql.window import Window

windowSpec = Window().partitionBy(['province']).orderBy('date').rowsBetween(-6,0)
timeprovinceWithRoll = timeprovince.withColumn("roll_7_confirmed",F.mean("confirmed").over(windowSpec))
timeprovinceWithRoll.filter(timeprovinceWithLag.date>'2020-03-10').show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Running Totals

# COMMAND ----------

from pyspark.sql.window import Window

windowSpec = Window().partitionBy(['province']).orderBy('date').rowsBetween(Window.unboundedPreceding,Window.currentRow)
timeprovinceWithRoll = timeprovince.withColumn("cumulative_confirmed",F.sum("confirmed").over(windowSpec))
timeprovinceWithRoll.filter(timeprovinceWithLag.date>'2020-03-10').show()

# COMMAND ----------

# MAGIC %md
# MAGIC # 6. Pivot Dataframes

# COMMAND ----------

pivotedTimeprovince = timeprovince.groupBy('date').pivot('province') \
                      .agg(F.sum('confirmed').alias('confirmed') , F.sum('released').alias('released'))
pivotedTimeprovince.limit(10).toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC # 7. Unpivot/Stack Dataframes

# COMMAND ----------

pivotedTimeprovince.columns  

# COMMAND ----------

newColnames = [x.replace("-","_") for x in pivotedTimeprovince.columns]

# COMMAND ----------

pivotedTimeprovince = pivotedTimeprovince.toDF(*newColnames)

# COMMAND ----------

expression = ""
cnt=0
for column in pivotedTimeprovince.columns:
    if column!='date':
        cnt +=1
        expression += f"'{column}' , {column},"
        
expression = f"stack({cnt}, {expression[:-1]}) as (Type,Value)"

# COMMAND ----------

unpivotedTimeprovince = pivotedTimeprovince.select('date',F.expr(expression))
unpivotedTimeprovince.show()

# COMMAND ----------

# MAGIC %md
# MAGIC # 8. Salting

# COMMAND ----------

cases = cases.withColumn("salt_key", F.concat(F.col("infection_case"), F.lit("_"), F.monotonically_increasing_id() % 10))

# COMMAND ----------

cases.show()

# COMMAND ----------

cases_temp = cases.groupBy(["infection_case","salt_key"]).agg(F.sum("confirmed").alias("salt_confirmed"))
cases_temp.show()

# COMMAND ----------

cases_answer = cases_temp.groupBy(["infection_case"]).agg(F.sum("salt_confirmed").alias("final_confirmed"))
cases_answer.show()